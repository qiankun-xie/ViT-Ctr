#!/usr/bin/env python3
"""
AutoDL Bootstrap训练脚本 — 解决两个问题:
1. 断网安全: 支持断点续训，用 tmux/nohup 运行即可
2. 速度优化: 预加载数据到内存，避免HDF5随机I/O瓶颈

用法:
    # AutoDL上 (tmux内运行)
    tmux new -s bootstrap
    python scripts/autodl_bootstrap.py --h5_dir /root/autodl-tmp/data --ckpt_dir /root/autodl-tmp/checkpoints
    # Ctrl+B, D 断开; tmux attach -t bootstrap 重连

    # 断点续训 (自动检测已完成的迭代数)
    python scripts/autodl_bootstrap.py --h5_dir ... --ckpt_dir ... --resume
"""
import argparse
import copy
import json
import os
import sys
import time

import h5py
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

# 添加src到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from model import SimpViT
from train import weighted_mse_loss
from utils.split import build_stratified_indices


# ── 配置 ──
N_BOOTSTRAP = 200
N_EPOCHS_PER_HEAD = 5
BOOTSTRAP_LR = 1e-3
BATCH_SIZE = 256       # GPU显存允许的话，比原来的64大4倍
SEED = 42


def preload_to_ram(h5_paths, indices):
    """一次性把所有样本加载到内存，返回 (fp_tensor, lbl_tensor)。

    这是最关键的优化: 避免训练时反复随机读HDF5。
    ~100万样本 × (2×64×64×4 + 3×4) bytes ≈ 3.3 GB，AutoDL实例通常有16+GB内存。
    """
    print(f"[preload] 预加载 {len(indices)} 个样本到内存...")
    t0 = time.time()

    # 打开所有文件
    handles = [h5py.File(p, 'r') for p in h5_paths]

    n = len(indices)
    fps = np.empty((n, 2, 64, 64), dtype=np.float32)
    lbls = np.empty((n, 3), dtype=np.float32)

    for i, entry in enumerate(indices):
        file_idx, sample_idx = entry[0], entry[1]
        fp = handles[file_idx]['fingerprints'][sample_idx]   # (64,64,2)
        fps[i] = fp.transpose(2, 0, 1)                       # (2,64,64)
        lbls[i] = handles[file_idx]['labels'][sample_idx]     # (3,)

    for h in handles:
        h.close()

    elapsed = time.time() - t0
    mem_gb = (fps.nbytes + lbls.nbytes) / 1e9
    print(f"[preload] 完成: {elapsed:.1f}s, 内存占用 {mem_gb:.2f} GB")

    return torch.from_numpy(fps), torch.from_numpy(lbls)


def freeze_backbone(model):
    """冻结除fc层以外的所有参数。"""
    for name, param in model.named_parameters():
        param.requires_grad = name.startswith('fc')
    return model


def run_bootstrap_autodl(model, train_fps, train_lbls, device, ckpt_dir, resume=False):
    """
    优化版Bootstrap:
    - 数据已在内存中 (TensorDataset)
    - 每完成一个head立即保存，支持断点续训
    - batch_size=256 充分利用GPU
    """
    heads_path = os.path.join(ckpt_dir, 'bootstrap_heads.pth')
    progress_path = os.path.join(ckpt_dir, 'bootstrap_progress.json')

    base_state = copy.deepcopy(model.state_dict())
    n_samples = len(train_fps)
    rng = np.random.default_rng(SEED)

    # 断点续训: 加载已完成的heads
    heads = []
    start_iter = 0
    if resume and os.path.exists(progress_path):
        with open(progress_path, 'r') as f:
            progress = json.load(f)
        start_iter = progress['completed']
        if os.path.exists(heads_path):
            saved = torch.load(heads_path, map_location='cpu', weights_only=False)
            heads = saved['heads'][:start_iter]
        # 快进RNG到正确位置
        for _ in range(start_iter):
            rng.choice(n_samples, size=n_samples, replace=True)
        print(f"[resume] 从第 {start_iter}/{N_BOOTSTRAP} 次迭代继续")

    for i in range(start_iter, N_BOOTSTRAP):
        t0 = time.time()

        # 有放回重采样 — 直接在内存tensor上索引
        boot_idx = rng.choice(n_samples, size=n_samples, replace=True)
        boot_fps = train_fps[boot_idx]
        boot_lbls = train_lbls[boot_idx]
        boot_ds = TensorDataset(boot_fps, boot_lbls)
        boot_loader = DataLoader(boot_ds, batch_size=BATCH_SIZE, shuffle=True,
                                 num_workers=4, pin_memory=True)

        # 从base state开始，冻结backbone
        model.load_state_dict(copy.deepcopy(base_state))
        model = freeze_backbone(model)
        model.to(device)
        opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=BOOTSTRAP_LR)

        # 微调fc头
        model.train()
        for epoch in range(N_EPOCHS_PER_HEAD):
            epoch_loss = 0.0
            n_steps = 0
            for fp, lbl in boot_loader:
                fp, lbl = fp.to(device, non_blocking=True), lbl.to(device, non_blocking=True)
                opt.zero_grad()
                pred = model(fp)
                loss = weighted_mse_loss(pred, lbl)
                loss.backward()
                opt.step()
                epoch_loss += loss.item()
                n_steps += 1

        # 保存fc头
        head_state = {k: v.clone().cpu() for k, v in model.state_dict().items() if k.startswith('fc')}
        heads.append(head_state)

        elapsed = time.time() - t0
        avg_loss = epoch_loss / max(n_steps, 1)
        print(f"[bootstrap {i+1:3d}/{N_BOOTSTRAP}] {elapsed:.1f}s | final_loss={avg_loss:.6f}")

        # 每个head都保存一次 — 断网安全
        torch.save({
            'heads': heads,
            'base_model_state_dict': base_state,
            'n_bootstrap': N_BOOTSTRAP,
            'debug_mode': False,
        }, heads_path)
        with open(progress_path, 'w') as f:
            json.dump({'completed': i + 1, 'total': N_BOOTSTRAP}, f)

    # 恢复base state
    model.load_state_dict(base_state)
    model.to(device)

    print(f"[bootstrap] 全部 {N_BOOTSTRAP} 次迭代完成!")
    return heads_path


def run_calibration(model, val_fps, val_lbls, bootstrap_ckpt, device, ckpt_dir):
    """在验证集上计算校准因子。"""
    from bootstrap import compute_jci, compute_coverage, calibrate_coverage

    base_state = bootstrap_ckpt['base_model_state_dict']
    heads = bootstrap_ckpt['heads']
    n = len(heads)
    p = 3

    val_ds = TensorDataset(val_fps, val_lbls)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False,
                            num_workers=4, pin_memory=True)

    print(f"[calibration] 用 {n} 个heads在 {len(val_fps)} 个验证样本上计算...")

    val_preds_all = []
    model.eval()
    with torch.no_grad():
        for head_state in heads:
            full_state = copy.deepcopy(base_state)
            full_state.update(head_state)
            model.load_state_dict(full_state)
            model.to(device)
            batch_preds = []
            for fp, _ in val_loader:
                fp = fp.to(device, non_blocking=True)
                batch_preds.append(model(fp).cpu().numpy())
            val_preds_all.append(np.vstack(batch_preds))

    val_preds_all = np.stack(val_preds_all)  # (200, n_val, 3)
    val_pred_mean = val_preds_all.mean(axis=0)
    val_pred_var = val_preds_all.var(axis=0, ddof=1)  # ddof=1 与 np.cov 一致
    y_true = val_lbls.numpy()

    from scipy.stats import f as fdist
    dfd = n - p
    f_val = fdist.ppf(0.95, dfn=p, dfd=dfd)
    val_pred_half = np.sqrt(val_pred_var * p * f_val / dfd)

    raw_coverage = compute_coverage(y_true, val_pred_mean, val_pred_half)
    cal_factors = calibrate_coverage(y_true, val_pred_mean, val_pred_half, target=0.95)
    calibrated_half = val_pred_half * np.array(cal_factors)
    final_coverage = compute_coverage(y_true, val_pred_mean, calibrated_half)

    cal_result = {
        'cal_factors': cal_factors,
        'empirical_coverage_before': raw_coverage.tolist(),
        'empirical_coverage_after': final_coverage.tolist(),
        'n_val_samples': len(y_true),
        'target_coverage': 0.95,
        'debug_mode': False,
    }
    cal_path = os.path.join(ckpt_dir, 'calibration.json')
    with open(cal_path, 'w') as f:
        json.dump(cal_result, f, indent=2)

    print(f"[calibration] Raw coverage: {raw_coverage}")
    print(f"[calibration] Calibrated coverage: {final_coverage}")
    print(f"[calibration] Factors: {cal_factors}")
    print(f"[calibration] 保存到 {cal_path}")


def main():
    parser = argparse.ArgumentParser(description="AutoDL Bootstrap训练 (断网安全+速度优化)")
    parser.add_argument('--h5_dir', type=str, required=True, help='HDF5数据目录')
    parser.add_argument('--ckpt_dir', type=str, required=True, help='checkpoint目录')
    parser.add_argument('--base_model', type=str, default=None,
                        help='base model路径 (默认: ckpt_dir/best_model.pth)')
    parser.add_argument('--resume', action='store_true', help='断点续训')
    parser.add_argument('--calibrate_only', action='store_true', help='仅运行校准(跳过bootstrap)')
    parser.add_argument('--batch_size', type=int, default=BATCH_SIZE, help='批大小 (默认256)')
    args = parser.parse_args()

    global BATCH_SIZE
    BATCH_SIZE = args.batch_size

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[main] Device: {device}")
    if device.type == 'cuda':
        print(f"[main] GPU: {torch.cuda.get_device_name()}")
        print(f"[main] VRAM: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")

    # 数据路径
    h5_paths = [os.path.join(args.h5_dir, f'{t}.h5')
                for t in ['dithioester', 'trithiocarbonate', 'xanthate', 'dithiocarbamate']]
    for p in h5_paths:
        if not os.path.exists(p):
            raise FileNotFoundError(f"HDF5文件不存在: {p}")

    # 数据划分
    train_idx, val_idx, _ = build_stratified_indices(h5_paths, seed=SEED)
    print(f"[main] Train: {len(train_idx)}, Val: {len(val_idx)}")

    # 预加载到内存 — 核心优化
    train_fps, train_lbls = preload_to_ram(h5_paths, train_idx)
    val_fps, val_lbls = preload_to_ram(h5_paths, val_idx)

    # 加载base model
    os.makedirs(args.ckpt_dir, exist_ok=True)
    base_model_path = args.base_model or os.path.join(args.ckpt_dir, 'best_model.pth')
    model = SimpViT(num_outputs=3).to(device)
    ckpt = torch.load(base_model_path, map_location=device, weights_only=True)
    model.load_state_dict(ckpt['model_state_dict'])
    print(f"[main] Loaded base model from {base_model_path}")

    if not args.calibrate_only:
        # Bootstrap训练
        heads_path = run_bootstrap_autodl(model, train_fps, train_lbls, device,
                                          args.ckpt_dir, resume=args.resume)
    else:
        heads_path = os.path.join(args.ckpt_dir, 'bootstrap_heads.pth')

    # 校准
    bootstrap_ckpt = torch.load(heads_path, map_location='cpu', weights_only=False)
    run_calibration(model, val_fps, val_lbls, bootstrap_ckpt, device, args.ckpt_dir)

    print("\n[main] 全部完成! 下载以下文件到本地:")
    print(f"  - {os.path.join(args.ckpt_dir, 'bootstrap_heads.pth')}")
    print(f"  - {os.path.join(args.ckpt_dir, 'calibration.json')}")


if __name__ == '__main__':
    main()
